
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Index
 */
@WebServlet("/Connexion")
public class Connexion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Connexion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String login =  request.getParameter("login");
		String pwd = request.getParameter("password");
		
		
		if("test".equalsIgnoreCase(login)&&"mdp".equalsIgnoreCase(pwd))
		{
			//cr�ation de la variable de session contenant les identifiants de l'utilisateur
            HttpSession session = request.getSession();
            session.setAttribute("login", login);
            session.setAttribute("pwd", pwd);
           
            /*
			this.getServletContext().getRequestDispatcher("/WEB-INF/bonjour.jsp").forward(request, response); 
            RequestDispatcher dispatcher;
            dispatcher=request.getRequestDispatcher("index.jsp");
            dispatcher.forward(request, response);
            */
		}
	}
	

}

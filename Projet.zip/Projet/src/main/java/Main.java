// Les importations Java n�cessaires au bon fonctionnement du code
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

// Ma classse "Main"
public class Main {
    
    // Les variables n�cessaires
    static Connection conn;
    static Statement state;
    static ResultSet result;
    static ResultSetMetaData resultMeta;
    static Object[][] donn;
    static String[] champs;
    static Object[] val;
    static String tableBDD = "compte";
    
    // D�marrage de l'application
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            
            // Ma m�thode "Run"
            public void run() {
                
                // Informations de connexion
                String BDD = "comptebancaire";
                String url = "jdbc:mysql://localhost:3306/" + BDD;
                String user = "root";
                String passwd = "root";
                
                // V�rification de la connexion avec la base de donn�es
                try {
                    Class.forName("com.mysql.jdbc.Driver");
                    conn = DriverManager.getConnection(url, user, passwd);
                    System.out.println("Connecter");
                    
                    // D�claration de la connexion avec la base de donn�e
                    Statement state = conn.createStatement();
                    //L'objet ResultSet contient le r�sultat de la requ�te SQL
                   
                    //code pour envoyer les donn�es

                    // On ferme tout les connexion � la base de donn�es
                    result.close();
                    state.close();
                } catch (Exception e){
                    e.printStackTrace();
                    System.out.println("Erreur");
                    System.exit(0);
                }
            }
        });
    }

}